AI CHATBOT USING OPENROUTER.AI

:REQUIREMENTS:
- Node.js (Required)
- API key from open source ai apps, ex: https://openrouter.ai

:NODE TUTORIAL (Since its already has node_module, instead paste the API key in .env:
- Download and install Node.js from > nodejs.org
- follow its instructions to install
- Download the chat.zip archive from this rep and extract it to whatever dir
- open your CLI (Shell or cmd) and must be on the same directory with the "chat" folder
- type command > npm init -y
                 npm install express axios body-parser

:OPENROUTER TUTORIAL:
- Login/create your account and get the API key
- paste it in the .env file
- and type a new command again > node server.js
- copy the localhost output and paste it in browser
